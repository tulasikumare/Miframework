package com.realmi.TestScripts;

import org.testng.annotations.Test;


import com.realmi.Lib.BaseTest;
import com.realmi.pages.realmipage;

/**
 * 
 * @author Tulsi
 *Perform cart operations
 */
public class realmipageaTest extends BaseTest{
	@Test
	public void realmipageaTest1()
	{
		// creating reference for cart page
		realmipage page=new realmipage(driver);
		//page.searchProduct("Redmi Note 9 Pro");
		page.searchProduct("Mi Smart Band 4");
		
		
	}
	 
}
