package com.realmi.Lib;

public class GenericLib {
	public static String sDirPath=System.getProperty("user.dir");
	public static String propertyfilePat1h=sDirPath + "/src/main/resources/Config/config.properties";
	public static String propertyfilePath="D:\\Appium\\realmicart\\Resource\\config.properties";
	public static String username="";
	public static String pass="";
	
}
