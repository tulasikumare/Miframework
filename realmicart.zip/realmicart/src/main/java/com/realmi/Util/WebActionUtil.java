package com.realmi.Util;

import java.util.logging.Logger;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.realmi.Lib.BasePage;

public class WebActionUtil {
	public    WebDriver driver;

	public static JavascriptExecutor jsExecutor;
	
	public final static Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public WebActionUtil(WebDriver driver)
	{
		this.driver=driver;
		
	}
	
	
	
	
	
	/*
	 * @Thulasi
	 * clickOnElement  method is used for clicking the element
	 * 
	 */
	
	
public static void clickOnElement(WebElement element, String elementName)
{
	try {
		logger.info("clicking on element");
		Thread.sleep(2);
		element.click();
	}catch(Exception E)
	{
		logger.info("element is not able to click");
	}
}

/*
 * @Thulasi
 * clickOnElementUsingJs  method is used for clicking the element using Java script executor
 */
public static void clickOnElementUsingJs(WebElement element, String elementName)
{
	try {
		logger.info("clicking on element using JS");
		jsExecutor.executeScript("arguments[0].click();", element);
	}catch(Exception E)
	{
		logger.info("element is not able to click");
	}
}

/*
 * @Thulasi
 * typingTheText  method is used for typing the text in textbox
 */
public static void typingTheText(WebElement element,String value, String elementName)
{
	try {
		logger.info("typing the text in text box");
		element.sendKeys(value);
		logger.info("User is able to type " + value + " into " + elementName);
	}catch(Exception E)
	{   
		logger.info(" User is not able to type " + value + " into " + elementName);
	}

}



}
