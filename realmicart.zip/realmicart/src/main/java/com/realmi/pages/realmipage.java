package com.realmi.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;


import com.realmi.Lib.BasePage;
import com.realmi.Util.WebActionUtil;

public class realmipage extends BasePage{

	public realmipage(WebDriver driver) {
		super(driver);
	
	}
	
	// typing the product name
	@FindBy(xpath="//nav[@class='site-navigation']//div[starts-with(@class,'search-section')]/form[@id='J_searchFormAction']/input[@id='J_searchTxt']")
	private  WebElement typeTheProduct;
	
	// clicking on product search icon
	@FindBy(xpath="//nav[@class='site-navigation']//div[starts-with(@class,'search-section')]/span[@class='right-search J_header_search J_header_search_true']/i[@class=' iconfont-search-24']")
	private  WebElement theProductSearchIcon;
	
	// moving the first product in the list
	@FindBy(xpath="//div[@class='content']//div[@class='goods-list-box']//div[@class='goods-list clearfix']/div[@class='goods-item'][1]//div[@class='figure figure-img']/a")
	private WebElement productLink;
	
	// clicking on cart option in first product in list
	@FindBy(xpath="//div[@class='content']//div[@class='goods-list-box']//div[@class='goods-list clearfix']/div[@class='goods-item'][1]//div[@class='actions clearfix']/a/span")
	private WebElement cartLink;
	
	//clicking the cart in Home page
	@FindBy(xpath="//div[@class='entry-board J_entryBoard']//div[@id='J_miniCartEntry']/a/span[text()='Cart ']")
	private WebElement maincartLink;
	
	//getting cart product number in the cart page
	@FindBy(xpath="//div[@id='root']//div[@class='cart-quantity']/div[@class='cart-quantity__item cart-quantity__number']")
	private WebElement cartvalueAuto;
	
	// clicking on the + for increase the cart value
	@FindBy(xpath="//div[@id='root']//div[@class='cart-quantity']/div[@class='cart-quantity__item cart-quantity__btn']/i")
	private WebElement cartPlus;
	
	//cart + disable
	@FindBy(xpath="//div[@id='root']//div[@class='cart-quantity']/div[@class='cart-quantity__item cart-quantity__btn cart-quantity__item--disabled']/i")
	private WebElement cartPlusdis;
	
	// clicking on the check out
	@FindBy(xpath="//div[@id='root']//div[@class='cart__footer-content container']/button[@class='cart__footer-checkout']")
	private WebElement checkOut;
	
	// clicking on the home icon for gettting back home page
	@FindBy(xpath="//div[@id='root']//div[@class='site-header__mi-logo']/a")
	private WebElement backToHome;
	
	// removing the cart item in home page cart
	@FindBy(xpath="//div[@class='entry-board J_entryBoard']//div[@class='filled-cart']/ul//a[@class='item-remove J_itemRemove']")
	private WebElement maincartRemove;
	
	// moving the product name the home page cart
	@FindBy(xpath="//div[@class='entry-board J_entryBoard']//div[@class='filled-cart']/ul//div[@class='item-name']/a")
	private WebElement cartName;
	
	/*
	 * @Thulasi
	 * searching the product and adding the cart into product and goto the cart
	 * and increasing the cart value
	 * come back to the home & removing the cart
	 * 
	 */
	public void searchProduct(String productname)
	{	
		// Creating reference of Avtion class to perform the mouse over actions
		Actions action = new Actions(driver);
		
		// this is wait method
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// crating reference for Java script executor to perform scoll s 
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		
		boolean ele=typeTheProduct.isDisplayed();
		
		System.out.println(ele);
		
		WebActionUtil.typingTheText(typeTheProduct, productname, " typing the phone model");
		WebActionUtil.clickOnElement(theProductSearchIcon, "theProductSearchIcon");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		action.moveToElement(productLink).build().perform();
		String stock=cartLink.getText();
		System.out.println(stock);
	
		if(stock.equalsIgnoreCase("ADD TO CART")) {
		
		for(int i=0;i<=20;i++)
		{
			try
		    {
		        
		        String data=driver.switchTo().alert().getText();
		       
				System.out.println(data);
				driver.switchTo().alert().accept();
				
				break;
		      // Alert exists and we switched to it
		    }
		    catch (NoAlertPresentException exception)
		    {
		    	WebActionUtil.clickOnElement(cartLink, "cart");
		       //this block will be executed in case alert is not present
		    }
		}
		
		
		jse.executeScript("window.scrollBy(0,-250)");
		
		action.moveToElement(maincartLink).build().perform();
		action.click();
		WebActionUtil.clickOnElement(maincartLink, "main cart");
	
		String cart1=cartvalueAuto.getText();
		System.out.println("No.of products added in cart is:"+cart1);
		
		jse.executeScript("window.scrollBy(0,-250)");
		action.moveToElement(backToHome).build().perform();
		WebActionUtil.clickOnElement(backToHome, "click home for return to back");
		
		action.moveToElement(maincartLink).build().perform();
		
		action.moveToElement(cartName).build().perform();
		WebActionUtil.clickOnElement(maincartRemove, "maincartRemove");
	}else if(stock.equalsIgnoreCase("OUT OF STOCK"))
	{
		System.out.println("out of stock please try some time");
	}
}
}
