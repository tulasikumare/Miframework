package com.realmi.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.realmi.Lib.BasePage;
import com.realmi.Util.WebActionUtil;

public class Logout extends BasePage{

	public Logout(WebDriver driver) {
		super(driver);
		
	}
	
	//Moving to customer Id
	@FindBy(xpath="//div[@class='entry-board J_entryBoard']//div[@class='entry user-entry J_foldingEntry']/a/span")
	private WebElement userId;
	// clicking on SIgn out 
	@FindBy(xpath="//div[@class='entry-board J_entryBoard']//div[@class='user-entry-list']/ul//a[text()='Sign Out']")
	private WebElement signOut;
	
	public void SignOut()
	{	Actions action = new Actions(driver);
		action.moveToElement(userId).build().perform();
		action.moveToElement(signOut).build().perform();
		WebActionUtil.clickOnElement(signOut, "Log out the account");
	}
}
