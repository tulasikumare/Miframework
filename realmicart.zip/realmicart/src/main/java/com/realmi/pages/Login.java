package com.realmi.pages;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.realmi.Lib.BasePage;
import com.realmi.Lib.GenericLib;
import com.realmi.Util.WebActionUtil;

public class Login extends BasePage{

	public Login(WebDriver driver) {
		super(driver);
		
	}
	@FindBy(xpath="//div[@class='entry-board J_entryBoard']//div[@class='sign-entries']//li[@class='entry']/a[text()='Sign in']")
	private  WebElement clickOnSignIn;
	
	@FindBy(xpath="//div[@class='login_area']//span[@class='sms_link']/a[@class='btnadpt btn_gray login_type_link']")
	private  WebElement clickOnSignInWithPass;
	@FindBy(xpath="//div[@class='login_area']//input[@id='username']")
	private  WebElement typingUsername;
	@FindBy(xpath="//div[@class='login_area']//input[@id='pwd']")
	private  WebElement typingPass;
	@FindBy(xpath="//div[@class='login_area']//input[@class='btnadpt']")
	private  WebElement clickingOnLoginsubmit;
	
	public void loginPage()
	{
		WebActionUtil.clickOnElement(clickOnSignIn, "clickOnSignIn");
		WebActionUtil.clickOnElement(clickOnSignInWithPass, "clickOnSignInWithPass");
		WebActionUtil.typingTheText(typingUsername, GenericLib.username, "username");
		WebActionUtil.typingTheText(typingPass, GenericLib.pass, "passwprd");
		WebActionUtil.clickOnElement(clickingOnLoginsubmit, "clickingOnLoginsubmit");
		try {
			Thread.sleep(9);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	    
	}
}
