package com.Iphone.TestScripts;

import org.testng.annotations.Test;

import com.Iphone.Pages.IphonePriceComparison;
import com.IphonePrice.Lib.BaseTest;

public class IphonePriceComparisonTest extends BaseTest{
@Test
public void IphonePriceComparisonPrice()
{
	IphonePriceComparison phone=new IphonePriceComparison(driver);
	phone.iphonePriceInAmazonAndFlipkart();
	
}
}
//div[@id="container"]/div/div[3]/div[2]/div/div[2]/div[2]/div/div/div/a/div[2]/div[1]/div[1]